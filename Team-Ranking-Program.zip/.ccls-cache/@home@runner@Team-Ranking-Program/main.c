#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct Team {
    int teamID;
    int won;
    int drawn;
    int lost;
    int GF;
    int GA;
    int GD;
    int points;
};

void printArray(struct Team *league, int size) {
    printf("TeamID\tWon\tDrawn\tLost\tGF\tGA\tGD\tPoints\n");
    for (int i = 0; i < size; i++) {
        printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", league[i].teamID, league[i].won, league[i].drawn,
               league[i].lost, league[i].GF, league[i].GA, league[i].GD, league[i].points);
    }
}

void swap(struct Team *a, struct Team *b) {
    struct Team temp = *a;
    *a = *b;
    *b = temp;
}

void bubbleSort(struct Team *league, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (league[j].points < league[j + 1].points) {
                swap(&league[j], &league[j + 1]);
            }
        }
    }
}

int score(struct Team *league) {
    for (int i = 0; i < 10; i++) {
        league[i].points = league[i].won * 3 + league[i].drawn;
    }

    bubbleSort(league, 10);

    return league[9].teamID;
}

int main() {
    struct Team league[10];
    srand(time(NULL));

    // Initialize the league array
    league[0].teamID = 1;
    league[1].teamID = 2;
    league[2].teamID = 3;
    league[3].teamID = 4;
    league[4].teamID = 5;
    league[5].teamID = 6;
    league[6].teamID = 7;
    league[7].teamID = 8;
    league[8].teamID = 9;
    league[9].teamID = 10;
    
    for (int i = 0; i < 10; i++) {
        league[i].GF = rand() % 16 + 35;
        league[i].GA = rand() % 16 + 35;
        league[i].GD = league[i].GF - league[i].GA;
        league[i].won = rand() % 8 + 7;
        league[i].drawn = rand() % 8 + 7;
        league[i].lost = 30 - league[i].won - league[i].drawn;
        league[i].points = 0;
    }

    printf("Initial Array:\n");
    printArray(league, 10);

    int championTeamID = score(league);

    printf("\nArray after calculating points and sorting:\n");
    printArray(league, 10);

    printf("\nChampion Team ID: %d\n", championTeamID);

    return 0;
}